import os
import json
import time
import signal
import sys
from typing import Dict, Any

import paho.mqtt.client as mqtt

from database import init_db, store_frame as store_sqlite
from supabase_client import store_frame as store_supabase

MQTT_BROKER = os.environ.get("MQTT_BROKER", "localhost")
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
VEHICLE_TOPIC = "sdv/+/telemetry"

running = True


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(f"Connected to MQTT broker at {MQTT_BROKER}:{MQTT_PORT}")
        client.subscribe(VEHICLE_TOPIC)
        print(f"Subscribed to {VEHICLE_TOPIC}")
    else:
        print(f"MQTT connection failed with code {rc}")


def on_message(client, userdata, msg):
    try:
        payload = msg.payload.decode("utf-8")
        data: Dict[str, Any] = json.loads(payload)

        vehicle_id = data.get("vehicle_id", "unknown")
        timestamp = data.get("timestamp", int(time.time() * 1000))
        readings = data.get("readings", [])

        store_sqlite(vehicle_id, timestamp, payload, readings)

        supabase_ok = store_supabase(vehicle_id, timestamp, payload, readings)
        if supabase_ok:
            print(f"[{vehicle_id}] Stored frame @ {timestamp} (SQLite + Supabase)")
        else:
            print(f"[{vehicle_id}] Stored frame @ {timestamp} (SQLite only)")

    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
    except Exception as e:
        print(f"Message processing error: {e}")


def on_disconnect(client, userdata, rc):
    print(f"Disconnected from MQTT broker (rc={rc})")


def signal_handler(sig, frame):
    global running
    print("\nShutting down...")
    running = False


def main():
    global running
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print("Initializing SQLite database...")
    init_db()

    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect

    while running:
        try:
            print(f"Connecting to MQTT broker {MQTT_BROKER}:{MQTT_PORT}...")
            client.connect(MQTT_BROKER, MQTT_PORT, 60)
            client.loop_start()

            while running:
                time.sleep(1)

            client.loop_stop()
            client.disconnect()
            break

        except Exception as e:
            print(f"Connection error: {e}")
            time.sleep(5)

    print("Telemetry collector stopped.")


if __name__ == "__main__":
    main()
