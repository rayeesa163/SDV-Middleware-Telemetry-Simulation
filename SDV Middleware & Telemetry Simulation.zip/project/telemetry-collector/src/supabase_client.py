import os
import json
from typing import List, Dict, Any
from supabase import create_client, Client

SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_ANON_KEY = os.environ.get("SUPABASE_ANON_KEY", "")

_supabase: Client | None = None


def get_client() -> Client:
    global _supabase
    if _supabase is None:
        if not SUPABASE_URL or not SUPABASE_ANON_KEY:
            raise RuntimeError("Supabase credentials not configured")
        _supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
    return _supabase


def store_frame(vehicle_id: str, timestamp: int, raw_json: str, readings: List[Dict[str, Any]]) -> bool:
    try:
        client = get_client()
        data = {
            "vehicle_id": vehicle_id,
            "timestamp": timestamp,
            "raw_json": raw_json,
            "readings": readings
        }
        result = client.table("telemetry_frames").insert(data).execute()
        return len(result.data) > 0
    except Exception as e:
        print(f"Supabase store error: {e}")
        return False


def get_latest_frames(limit: int = 100) -> List[Dict[str, Any]]:
    try:
        client = get_client()
        result = client.table("telemetry_frames") \
            .select("*") \
            .order("timestamp", desc=True) \
            .limit(limit) \
            .execute()
        return result.data
    except Exception as e:
        print(f"Supabase query error: {e}")
        return []
