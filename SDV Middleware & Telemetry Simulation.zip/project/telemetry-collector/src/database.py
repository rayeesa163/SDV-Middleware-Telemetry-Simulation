import sqlite3
import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional

DB_PATH = os.environ.get("SQLITE_DB", "/data/telemetry.db")


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS telemetry_frames (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id TEXT NOT NULL,
            timestamp INTEGER NOT NULL,
            received_at TEXT NOT NULL,
            raw_json TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sensor_readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            frame_id INTEGER NOT NULL,
            sensor_id TEXT NOT NULL,
            sensor_type TEXT NOT NULL,
            value REAL,
            value_str TEXT,
            unit TEXT,
            quality REAL,
            timestamp INTEGER NOT NULL,
            FOREIGN KEY (frame_id) REFERENCES telemetry_frames(id)
        )
    """)

    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_frames_vehicle_ts
        ON telemetry_frames(vehicle_id, timestamp)
    """)

    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_readings_type_ts
        ON sensor_readings(sensor_type, timestamp)
    """)

    conn.commit()
    conn.close()


def store_frame(vehicle_id: str, timestamp: int, raw_json: str, readings: List[Dict[str, Any]]) -> int:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO telemetry_frames (vehicle_id, timestamp, received_at, raw_json) VALUES (?, ?, ?, ?)",
        (vehicle_id, timestamp, datetime.utcnow().isoformat(), raw_json)
    )
    frame_id = cursor.lastrowid

    for reading in readings:
        value = reading.get("value")
        value_str = None
        if isinstance(value, str):
            value_str = value
            value = None

        cursor.execute(
            """INSERT INTO sensor_readings
               (frame_id, sensor_id, sensor_type, value, value_str, unit, quality, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                frame_id,
                reading.get("sensor_id", ""),
                reading.get("type", ""),
                value,
                value_str,
                reading.get("unit", ""),
                reading.get("quality", 1.0),
                reading.get("timestamp", timestamp)
            )
        )

    conn.commit()
    conn.close()
    return frame_id


def get_latest_readings(sensor_type: str, limit: int = 100) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute(
        """SELECT sensor_type, value, value_str, unit, quality, timestamp
           FROM sensor_readings
           WHERE sensor_type = ?
           ORDER BY timestamp DESC
           LIMIT ?""",
        (sensor_type, limit)
    )

    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_recent_frames(vehicle_id: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if vehicle_id:
        cursor.execute(
            "SELECT * FROM telemetry_frames WHERE vehicle_id = ? ORDER BY timestamp DESC LIMIT ?",
            (vehicle_id, limit)
        )
    else:
        cursor.execute(
            "SELECT * FROM telemetry_frames ORDER BY timestamp DESC LIMIT ?",
            (limit,)
        )

    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_stats() -> Dict[str, Any]:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM telemetry_frames")
    frame_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM sensor_readings")
    reading_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(DISTINCT vehicle_id) FROM telemetry_frames")
    vehicle_count = cursor.fetchone()[0]

    cursor.execute("SELECT MAX(timestamp) FROM telemetry_frames")
    last_ts = cursor.fetchone()[0]

    conn.close()

    return {
        "frame_count": frame_count,
        "reading_count": reading_count,
        "vehicle_count": vehicle_count,
        "last_timestamp": last_ts
    }
