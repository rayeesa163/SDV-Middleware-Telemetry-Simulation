import os
import json
import time
import math
import random
import signal
from datetime import datetime
from typing import List, Dict, Any

import paho.mqtt.client as mqtt

MQTT_BROKER = os.environ.get("MQTT_BROKER", "localhost")
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
VEHICLE_ID = os.environ.get("VEHICLE_ID", "VEH-001")
RATE_HZ = int(os.environ.get("SIMULATION_RATE_HZ", "10"))

running = True


def signal_handler(sig, frame):
    global running
    print("\nShutting down sensor simulator...")
    running = False


class VehicleModel:
    def __init__(self):
        self.speed_kmh = 0.0
        self.rpm = 0.0
        self.engine_temp_c = 90.0
        self.battery_voltage = 12.6
        self.battery_soc = 85.0
        self.fuel_level = 75.0
        self.odometer_km = 12345.6
        self.latitude = 37.7749
        self.longitude = -122.4194
        self.heading = 0.0
        self.accel_x = 0.0
        self.accel_y = 0.0
        self.accel_z = 0.0
        self.brake_pressed = False
        self.gear = 1
        self.timestamp_ms = 0

        self._target_speed = 0.0
        self._speed_change_timer = 0.0
        self._rng = random.Random()
        self._pick_new_target_speed()

    def _pick_new_target_speed(self):
        phase = random.random()
        if phase < 0.3:
            self._target_speed = 0.0
        elif phase < 0.5:
            self._target_speed = 30.0 + random.random() * 20.0
        elif phase < 0.8:
            self._target_speed = 60.0 + random.random() * 40.0
        else:
            self._target_speed = 100.0 + random.random() * 50.0
        self._speed_change_timer = 5.0 + random.random() * 20.0

    def update(self, dt: float):
        self._speed_change_timer -= dt
        if self._speed_change_timer <= 0.0:
            self._pick_new_target_speed()

        diff = self._target_speed - self.speed_kmh
        accel = 15.0
        if abs(diff) < 1.0:
            self.speed_kmh = self._target_speed
        else:
            change = (1.0 if diff > 0 else -1.0) * accel * dt
            if abs(change) > abs(diff):
                change = diff
            self.speed_kmh += change

        self.speed_kmh = max(0.0, min(200.0, self.speed_kmh))
        self.odometer_km += (self.speed_kmh / 3600.0) * dt

        if self.speed_kmh < 1.0:
            self.rpm = 800.0 + random.gauss(0, 20)
        else:
            gear_ratio = 1.0 + (6 - self.gear) * 0.3
            self.rpm = 800.0 + (self.speed_kmh * 35.0 * gear_ratio) + random.gauss(0, 30)
        self.rpm = max(0.0, min(7000.0, self.rpm))

        ambient = 25.0
        target_temp = 90.0 + self.speed_kmh * 0.05 if self.speed_kmh > 5.0 else 85.0
        self.engine_temp_c += (target_temp - self.engine_temp_c) * 0.02 * dt + random.gauss(0, 0.1)
        self.engine_temp_c = max(ambient, min(120.0, self.engine_temp_c))

        load = self.rpm / 7000.0 + self.speed_kmh / 200.0
        target_volt = 13.8 - load * 0.5
        self.battery_voltage += (target_volt - self.battery_voltage) * 0.1 * dt + random.gauss(0, 0.01)
        self.battery_voltage = max(10.0, min(15.0, self.battery_voltage))

        self.battery_soc -= (load * 0.0001 * dt) + random.gauss(0, 0.0001)
        self.battery_soc = max(0.0, min(100.0, self.battery_soc))

        consumption = (self.rpm / 7000.0) * 0.001 * dt
        self.fuel_level -= consumption + random.gauss(0, 0.00001)
        self.fuel_level = max(0.0, min(100.0, self.fuel_level))

        if self.speed_kmh >= 0.5:
            speed_ms = self.speed_kmh / 3.6
            dist = speed_ms * dt
            self.heading += random.gauss(0, 0.5)
            self.heading %= 360.0
            rad = math.radians(self.heading)
            lat_rad = math.radians(self.latitude)
            dlat = dist * math.cos(rad) / 111320.0
            dlon = dist * math.sin(rad) / (111320.0 * math.cos(lat_rad))
            self.latitude += dlat
            self.longitude += dlon

        self.accel_x = random.gauss(0, 0.1)
        self.accel_y = random.gauss(0, 0.1)
        self.accel_z = 1.0 + random.gauss(0, 0.05)
        if self.brake_pressed:
            self.accel_x -= 2.0 + random.random() * 3.0

        if self.speed_kmh > 0.1:
            self.brake_pressed = random.random() < 0.02
        else:
            self.brake_pressed = False

        if self.speed_kmh > 30.0:
            self.gear = min(6, 3 + int(self.speed_kmh / 40.0))
        elif self.speed_kmh > 10.0:
            self.gear = 2
        else:
            self.gear = 1

        self.timestamp_ms = int(datetime.utcnow().timestamp() * 1000)


def build_reading(sensor_id: str, sensor_type: str, value, unit: str, quality: float, timestamp: int) -> Dict[str, Any]:
    reading = {
        "sensor_id": sensor_id,
        "type": sensor_type,
        "unit": unit,
        "timestamp": timestamp,
        "quality": round(quality, 3)
    }
    if sensor_type == "gps":
        reading["value"] = value
    else:
        reading["value"] = value
    return reading


def publish_frame(client: mqtt.Client, vehicle: VehicleModel):
    ts = vehicle.timestamp_ms
    readings = [
        build_reading("SPD-01", "speed", round(vehicle.speed_kmh, 2), "km/h", 0.98, ts),
        build_reading("RPM-01", "rpm", round(vehicle.rpm, 2), "rpm", 0.97, ts),
        build_reading("TMP-01", "engine_temp", round(vehicle.engine_temp_c, 2), "C", 0.95, ts),
        build_reading("BAT-V-01", "battery_voltage", round(vehicle.battery_voltage, 2), "V", 0.96, ts),
        build_reading("BAT-SOC-01", "battery_soc", round(vehicle.battery_soc, 2), "%", 0.94, ts),
        build_reading("FUE-01", "fuel_level", round(vehicle.fuel_level, 2), "%", 0.93, ts),
        build_reading("GPS-01", "gps", f"{vehicle.latitude:.6f},{vehicle.longitude:.6f}", "lat,lon", 0.99, ts),
        build_reading("ACC-01", "accelerometer", round(vehicle.accel_x, 3), "g", 0.95, ts),
        build_reading("BRK-01", "brake", 1.0 if vehicle.brake_pressed else 0.0, "bool", 0.99, ts),
        build_reading("GR-01", "gear", vehicle.gear, "int", 0.98, ts),
    ]

    payload = {
        "vehicle_id": VEHICLE_ID,
        "timestamp": ts,
        "readings": readings
    }

    topic = f"sdv/{VEHICLE_ID}/telemetry"
    client.publish(topic, json.dumps(payload), qos=0)


def main():
    global running
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print("Python SDV Sensor Simulator")
    print(f"  Vehicle: {VEHICLE_ID}")
    print(f"  MQTT Broker: {MQTT_BROKER}:{MQTT_PORT}")
    print(f"  Rate: {RATE_HZ} Hz")

    client = mqtt.Client()

    def on_connect(c, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT broker")
        else:
            print(f"MQTT connect failed: {rc}")

    client.on_connect = on_connect

    while running:
        try:
            client.connect(MQTT_BROKER, MQTT_PORT, 60)
            client.loop_start()
            break
        except Exception as e:
            print(f"Connection error: {e}, retrying...")
            time.sleep(5)

    if not running:
        return

    vehicle = VehicleModel()
    interval = 1.0 / RATE_HZ

    print("Simulation running...")

    while running:
        vehicle.update(interval)
        publish_frame(client, vehicle)
        time.sleep(interval)

    client.loop_stop()
    client.disconnect()
    print("Sensor simulator stopped.")


if __name__ == "__main__":
    main()
