import os
import sys
import json
import time
import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "telemetry-collector", "src"))
from database import get_latest_readings, get_recent_frames, get_stats, DB_PATH

st.set_page_config(
    page_title="SDV Telemetry Dashboard",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
    <style>
    .main > div { padding-top: 1rem; }
    .stMetric { background: #f8f9fa; border-radius: 8px; padding: 10px; }
    </style>
""", unsafe_allow_html=True)

st.title("SDV Middleware & Telemetry Simulator")
st.markdown("Real-time vehicle telemetry monitoring and analytics")

DB_PATH_LOCAL = os.environ.get("SQLITE_DB", "/data/telemetry.db")


def get_db_connection():
    return sqlite3.connect(DB_PATH_LOCAL)


@st.cache_data(ttl=5)
def fetch_sensor_history(sensor_type: str, minutes: int = 5) -> pd.DataFrame:
    conn = get_db_connection()
    cutoff = int((datetime.utcnow() - timedelta(minutes=minutes)).timestamp() * 1000)
    query = """
        SELECT sensor_type, value, value_str, unit, quality, timestamp
        FROM sensor_readings
        WHERE sensor_type = ? AND timestamp > ?
        ORDER BY timestamp ASC
    """
    df = pd.read_sql_query(query, conn, params=(sensor_type, cutoff))
    conn.close()
    if not df.empty:
        df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms")
    return df


@st.cache_data(ttl=5)
def fetch_all_recent(minutes: int = 5) -> pd.DataFrame:
    conn = get_db_connection()
    cutoff = int((datetime.utcnow() - timedelta(minutes=minutes)).timestamp() * 1000)
    query = """
        SELECT sensor_type, value, value_str, unit, quality, timestamp
        FROM sensor_readings
        WHERE timestamp > ?
        ORDER BY timestamp ASC
    """
    df = pd.read_sql_query(query, conn, params=(cutoff,))
    conn.close()
    if not df.empty:
        df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms")
    return df


@st.cache_data(ttl=5)
def fetch_stats():
    return get_stats()


@st.cache_data(ttl=5)
def fetch_vehicle_summary(minutes: int = 5) -> pd.DataFrame:
    conn = get_db_connection()
    cutoff = int((datetime.utcnow() - timedelta(minutes=minutes)).timestamp() * 1000)
    query = """
        SELECT tf.vehicle_id, sr.sensor_type, sr.value, sr.timestamp
        FROM telemetry_frames tf
        JOIN sensor_readings sr ON tf.id = sr.frame_id
        WHERE tf.timestamp > ?
    """
    df = pd.read_sql_query(query, conn, params=(cutoff,))
    conn.close()
    return df


# Sidebar controls
st.sidebar.header("Controls")
refresh_interval = st.sidebar.slider("Refresh interval (seconds)", 1, 30, 5)
time_window = st.sidebar.selectbox("Time window", ["1 min", "5 min", "15 min", "30 min"], index=1)
window_map = {"1 min": 1, "5 min": 5, "15 min": 15, "30 min": 30}
window_minutes = window_map[time_window]

st.sidebar.markdown("---")
st.sidebar.subheader("System Info")

# Auto-refresh
st_autorefresh = st.empty()

# Stats row
stats = fetch_stats()
cols = st.columns(4)
cols[0].metric("Total Frames", stats.get("frame_count", 0))
cols[1].metric("Sensor Readings", stats.get("reading_count", 0))
cols[2].metric("Vehicles", stats.get("vehicle_count", 0))
last_ts = stats.get("last_timestamp")
if last_ts:
    last_dt = datetime.fromtimestamp(last_ts / 1000.0)
    cols[3].metric("Last Update", last_dt.strftime("%H:%M:%S"))
else:
    cols[3].metric("Last Update", "N/A")

st.divider()

# Main charts
st.subheader("Vehicle Telemetry")

# Speed and RPM
speed_df = fetch_sensor_history("speed", window_minutes)
rpm_df = fetch_sensor_history("rpm", window_minutes)
temp_df = fetch_sensor_history("engine_temp", window_minutes)
volt_df = fetch_sensor_history("battery_voltage", window_minutes)
fuel_df = fetch_sensor_history("fuel_level", window_minutes)

if not speed_df.empty and not rpm_df.empty:
    fig1 = make_subplots(
        rows=2, cols=2,
        subplot_titles=("Speed (km/h)", "Engine RPM", "Engine Temperature (C)", "Battery Voltage (V)"),
        vertical_spacing=0.12
    )

    fig1.add_trace(
        go.Scatter(x=speed_df["datetime"], y=speed_df["value"], mode="lines", name="Speed", line=dict(color="#2E86AB")),
        row=1, col=1
    )
    fig1.add_trace(
        go.Scatter(x=rpm_df["datetime"], y=rpm_df["value"], mode="lines", name="RPM", line=dict(color="#A23B72")),
        row=1, col=2
    )

    if not temp_df.empty:
        fig1.add_trace(
            go.Scatter(x=temp_df["datetime"], y=temp_df["value"], mode="lines", name="Temp", line=dict(color="#F18F01")),
            row=2, col=1
        )

    if not volt_df.empty:
        fig1.add_trace(
            go.Scatter(x=volt_df["datetime"], y=volt_df["value"], mode="lines", name="Voltage", line=dict(color="#C73E1D")),
            row=2, col=2
        )

    fig1.update_layout(height=600, showlegend=False, template="plotly_white")
    fig1.update_xaxes(showgrid=True)
    fig1.update_yaxes(showgrid=True)
    st.plotly_chart(fig1, width='stretch')
else:
    st.info("Waiting for telemetry data... Ensure the sensor simulator and MQTT broker are running.")

st.divider()

# Gauges
st.subheader("Current Values")
gauge_cols = st.columns(4)

if not speed_df.empty:
    latest_speed = speed_df["value"].iloc[-1]
    gauge_cols[0].plotly_chart(
        go.Figure(go.Indicator(
            mode="gauge+number",
            value=latest_speed,
            title={"text": "Speed (km/h)"},
            gauge={"axis": {"range": [0, 200]}, "bar": {"color": "#2E86AB"}}
        )).update_layout(height=250, margin=dict(l=20, r=20, t=50, b=20)),
        width='stretch'
    )

if not rpm_df.empty:
    latest_rpm = rpm_df["value"].iloc[-1]
    gauge_cols[1].plotly_chart(
        go.Figure(go.Indicator(
            mode="gauge+number",
            value=latest_rpm,
            title={"text": "RPM"},
            gauge={"axis": {"range": [0, 7000]}, "bar": {"color": "#A23B72"}}
        )).update_layout(height=250, margin=dict(l=20, r=20, t=50, b=20)),
        width='stretch'
    )

if not temp_df.empty:
    latest_temp = temp_df["value"].iloc[-1]
    gauge_cols[2].plotly_chart(
        go.Figure(go.Indicator(
            mode="gauge+number",
            value=latest_temp,
            title={"text": "Engine Temp (C)"},
            gauge={"axis": {"range": [0, 120]}, "bar": {"color": "#F18F01"}}
        )).update_layout(height=250, margin=dict(l=20, r=20, t=50, b=20)),
        width='stretch'
    )

if not volt_df.empty:
    latest_volt = volt_df["value"].iloc[-1]
    gauge_cols[3].plotly_chart(
        go.Figure(go.Indicator(
            mode="gauge+number",
            value=latest_volt,
            title={"text": "Battery (V)"},
            gauge={"axis": {"range": [10, 15]}, "bar": {"color": "#C73E1D"}}
        )).update_layout(height=250, margin=dict(l=20, r=20, t=50, b=20)),
        width='stretch'
    )

st.divider()

# Fuel level
if not fuel_df.empty:
    st.subheader("Fuel Level")
    fig_fuel = px.area(
        fuel_df, x="datetime", y="value",
        labels={"value": "Fuel Level (%)", "datetime": "Time"},
        color_discrete_sequence=["#3A7D44"]
    )
    fig_fuel.update_layout(template="plotly_white", height=300)
    st.plotly_chart(fig_fuel, width='stretch')

st.divider()

# Raw data table
with st.expander("Recent Telemetry Frames"):
    frames = get_recent_frames(limit=20)
    if frames:
        df_frames = pd.DataFrame(frames)
        df_frames["received_at"] = pd.to_datetime(df_frames["received_at"])
        st.dataframe(df_frames[["vehicle_id", "timestamp", "received_at"]], width='stretch')
    else:
        st.write("No frames available yet.")

# Auto refresh
st_autorefresh.text(f"Auto-refreshing every {refresh_interval}s")
time.sleep(refresh_interval)
st.rerun()
