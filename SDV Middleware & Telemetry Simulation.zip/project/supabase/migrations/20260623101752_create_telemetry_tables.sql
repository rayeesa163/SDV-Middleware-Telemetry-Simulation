/*
# Create telemetry tables for SDV Simulator

1. New Tables
- `telemetry_frames`
  - `id` (uuid, primary key)
  - `vehicle_id` (text, not null) - identifies the simulated vehicle
  - `timestamp` (bigint, not null) - frame timestamp in milliseconds
  - `raw_json` (text, not null) - full JSON payload
  - `readings` (jsonb) - parsed sensor readings array
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `telemetry_frames`.
- Allow anon + authenticated CRUD because this is a single-tenant telemetry simulator with no auth required.
*/

CREATE TABLE IF NOT EXISTS telemetry_frames (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id text NOT NULL,
    timestamp bigint NOT NULL,
    raw_json text NOT NULL,
    readings jsonb,
    created_at timestamptz DEFAULT now()
);

ALTER TABLE telemetry_frames ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_telemetry" ON telemetry_frames;
CREATE POLICY "anon_select_telemetry" ON telemetry_frames FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_telemetry" ON telemetry_frames;
CREATE POLICY "anon_insert_telemetry" ON telemetry_frames FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_telemetry" ON telemetry_frames;
CREATE POLICY "anon_update_telemetry" ON telemetry_frames FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_telemetry" ON telemetry_frames;
CREATE POLICY "anon_delete_telemetry" ON telemetry_frames FOR DELETE
TO anon, authenticated USING (true);
