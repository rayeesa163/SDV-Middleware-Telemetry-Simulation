#pragma once

#include "sensor.hpp"
#include <mosquitto.h>
#include <string>
#include <vector>
#include <memory>

namespace sdv {

class MqttPublisher {
public:
    MqttPublisher(const std::string& broker, int port, const std::string& client_id);
    ~MqttPublisher();

    bool connect();
    void disconnect();
    bool publish(const std::string& topic, const std::string& payload, int qos = 0);
    bool isConnected() const;

private:
    struct mosquitto* mosq_ = nullptr;
    std::string broker_;
    int port_;
    std::string client_id_;
    bool connected_ = false;
};

class TelemetryPublisher {
public:
    TelemetryPublisher(const std::string& broker, int port,
                       const std::string& vehicle_id,
                       const std::vector<std::unique_ptr<Sensor>>& sensors);
    ~TelemetryPublisher();

    bool start();
    void stop();
    void publishFrame(const VehicleState& state);

private:
    MqttPublisher mqtt_;
    std::string vehicle_id_;
    const std::vector<std::unique_ptr<Sensor>>& sensors_;
    bool running_ = false;

    std::string buildTopic(const std::string& sensor_type) const;
    std::string buildPayload(const SensorReading& reading) const;
};

} // namespace sdv
