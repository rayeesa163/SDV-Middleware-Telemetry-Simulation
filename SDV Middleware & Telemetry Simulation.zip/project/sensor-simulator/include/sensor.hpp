#pragma once

#include "vehicle_model.hpp"
#include <string>

namespace sdv {

struct SensorReading {
    std::string sensor_id;
    std::string sensor_type;
    double value;
    std::string unit;
    uint64_t timestamp_ms;
    double quality; // 0.0 - 1.0
};

class Sensor {
public:
    explicit Sensor(const std::string& id, const std::string& type, const std::string& unit);
    virtual ~Sensor() = default;
    virtual SensorReading read(const VehicleState& state) = 0;

protected:
    std::string id_;
    std::string type_;
    std::string unit_;
    uint64_t nowMs() const;
};

class SpeedSensor : public Sensor {
public:
    SpeedSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class RPMSensor : public Sensor {
public:
    RPMSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class TemperatureSensor : public Sensor {
public:
    TemperatureSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class BatteryVoltageSensor : public Sensor {
public:
    BatteryVoltageSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class BatterySOCSensor : public Sensor {
public:
    BatterySOCSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class FuelLevelSensor : public Sensor {
public:
    FuelLevelSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class GPSSensor : public Sensor {
public:
    GPSSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class AccelerometerSensor : public Sensor {
public:
    AccelerometerSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class BrakeSensor : public Sensor {
public:
    BrakeSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

class GearSensor : public Sensor {
public:
    GearSensor(const std::string& id);
    SensorReading read(const VehicleState& state) override;
};

} // namespace sdv
