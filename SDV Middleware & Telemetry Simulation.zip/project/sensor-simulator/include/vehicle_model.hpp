#pragma once

#include <cmath>
#include <random>

namespace sdv {

struct VehicleState {
    double speed_kmh = 0.0;
    double rpm = 0.0;
    double engine_temp_c = 90.0;
    double battery_voltage = 12.6;
    double battery_soc = 85.0;
    double fuel_level = 75.0;
    double odometer_km = 12345.6;
    double latitude = 37.7749;
    double longitude = -122.4194;
    double heading = 0.0;
    double accel_x = 0.0;
    double accel_y = 0.0;
    double accel_z = 0.0;
    bool brake_pressed = false;
    int gear = 1;
    uint64_t timestamp_ms = 0;
};

class VehicleModel {
public:
    VehicleModel();
    void update(double dt_seconds);
    const VehicleState& state() const { return state_; }

private:
    VehicleState state_;
    std::mt19937 rng_;
    std::normal_distribution<double> noise_dist_;
    std::uniform_real_distribution<double> uniform_dist_;

    double target_speed_ = 0.0;
    double speed_change_timer_ = 0.0;
    double engine_temp_target_ = 90.0;
    double engine_temp_rise_rate_ = 0.0;

    void updateSpeed(double dt);
    void updateRPM();
    void updateEngineTemp(double dt);
    void updateBattery(double dt);
    void updateFuel(double dt);
    void updateGPS(double dt);
    void updateAccelerometer();
    void pickNewTargetSpeed();
};

} // namespace sdv
