#include "sensor.hpp"
#include <chrono>
#include <sstream>
#include <iomanip>

namespace sdv {

uint64_t Sensor::nowMs() const {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

Sensor::Sensor(const std::string& id, const std::string& type, const std::string& unit)
    : id_(id), type_(type), unit_(unit) {}

SpeedSensor::SpeedSensor(const std::string& id) : Sensor(id, "speed", "km/h") {}

SensorReading SpeedSensor::read(const VehicleState& state) {
    return {id_, type_, state.speed_kmh, unit_, nowMs(), 0.98};
}

RPMSensor::RPMSensor(const std::string& id) : Sensor(id, "rpm", "rpm") {}

SensorReading RPMSensor::read(const VehicleState& state) {
    return {id_, type_, state.rpm, unit_, nowMs(), 0.97};
}

TemperatureSensor::TemperatureSensor(const std::string& id) : Sensor(id, "engine_temp", "C") {}

SensorReading TemperatureSensor::read(const VehicleState& state) {
    return {id_, type_, state.engine_temp_c, unit_, nowMs(), 0.95};
}

BatteryVoltageSensor::BatteryVoltageSensor(const std::string& id) : Sensor(id, "battery_voltage", "V") {}

SensorReading BatteryVoltageSensor::read(const VehicleState& state) {
    return {id_, type_, state.battery_voltage, unit_, nowMs(), 0.96};
}

BatterySOCSensor::BatterySOCSensor(const std::string& id) : Sensor(id, "battery_soc", "%") {}

SensorReading BatterySOCSensor::read(const VehicleState& state) {
    return {id_, type_, state.battery_soc, unit_, nowMs(), 0.94};
}

FuelLevelSensor::FuelLevelSensor(const std::string& id) : Sensor(id, "fuel_level", "%") {}

SensorReading FuelLevelSensor::read(const VehicleState& state) {
    return {id_, type_, state.fuel_level, unit_, nowMs(), 0.93};
}

GPSSensor::GPSSensor(const std::string& id) : Sensor(id, "gps", "lat,lon") {}

SensorReading GPSSensor::read(const VehicleState& state) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6) << state.latitude << "," << state.longitude;
    return {id_, type_, 0.0, oss.str(), nowMs(), 0.99};
}

AccelerometerSensor::AccelerometerSensor(const std::string& id) : Sensor(id, "accelerometer", "g") {}

SensorReading AccelerometerSensor::read(const VehicleState& state) {
    return {id_, type_, state.accel_x, unit_, nowMs(), 0.95};
}

BrakeSensor::BrakeSensor(const std::string& id) : Sensor(id, "brake", "bool") {}

SensorReading BrakeSensor::read(const VehicleState& state) {
    return {id_, type_, state.brake_pressed ? 1.0 : 0.0, unit_, nowMs(), 0.99};
}

GearSensor::GearSensor(const std::string& id) : Sensor(id, "gear", "int") {}

SensorReading GearSensor::read(const VehicleState& state) {
    return {id_, type_, static_cast<double>(state.gear), unit_, nowMs(), 0.98};
}

} // namespace sdv
