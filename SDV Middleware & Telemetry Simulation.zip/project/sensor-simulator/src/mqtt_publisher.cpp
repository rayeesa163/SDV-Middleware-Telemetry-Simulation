#include "mqtt_publisher.hpp"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstring>

namespace sdv {

MqttPublisher::MqttPublisher(const std::string& broker, int port, const std::string& client_id)
    : broker_(broker), port_(port), client_id_(client_id) {
    mosquitto_lib_init();
    mosq_ = mosquitto_new(client_id_.c_str(), true, nullptr);
    if (!mosq_) {
        std::cerr << "Failed to create mosquitto client" << std::endl;
    }
}

MqttPublisher::~MqttPublisher() {
    disconnect();
    if (mosq_) {
        mosquitto_destroy(mosq_);
    }
    mosquitto_lib_cleanup();
}

bool MqttPublisher::connect() {
    if (!mosq_) return false;

    int rc = mosquitto_connect(mosq_, broker_.c_str(), port_, 60);
    if (rc != MOSQ_ERR_SUCCESS) {
        std::cerr << "MQTT connect failed: " << mosquitto_strerror(rc) << std::endl;
        return false;
    }

    rc = mosquitto_loop_start(mosq_);
    if (rc != MOSQ_ERR_SUCCESS) {
        std::cerr << "MQTT loop start failed: " << mosquitto_strerror(rc) << std::endl;
        return false;
    }

    connected_ = true;
    std::cout << "Connected to MQTT broker at " << broker_ << ":" << port_ << std::endl;
    return true;
}

void MqttPublisher::disconnect() {
    if (mosq_ && connected_) {
        mosquitto_loop_stop(mosq_, true);
        mosquitto_disconnect(mosq_);
        connected_ = false;
    }
}

bool MqttPublisher::publish(const std::string& topic, const std::string& payload, int qos) {
    if (!mosq_ || !connected_) return false;

    int rc = mosquitto_publish(mosq_, nullptr, topic.c_str(),
                               static_cast<int>(payload.length()),
                               payload.c_str(), qos, false);
    if (rc != MOSQ_ERR_SUCCESS) {
        std::cerr << "MQTT publish failed: " << mosquitto_strerror(rc) << std::endl;
        return false;
    }
    return true;
}

bool MqttPublisher::isConnected() const {
    return connected_;
}

// TelemetryPublisher

TelemetryPublisher::TelemetryPublisher(const std::string& broker, int port,
                                       const std::string& vehicle_id,
                                       const std::vector<std::unique_ptr<Sensor>>& sensors)
    : mqtt_(broker, port, vehicle_id + "_pub"),
      vehicle_id_(vehicle_id),
      sensors_(sensors) {}

TelemetryPublisher::~TelemetryPublisher() {
    stop();
}

bool TelemetryPublisher::start() {
    return mqtt_.connect();
}

void TelemetryPublisher::stop() {
    running_ = false;
    mqtt_.disconnect();
}

void TelemetryPublisher::publishFrame(const VehicleState& state) {
    std::ostringstream frame;
    frame << "{";
    frame << "\"vehicle_id\":\"" << vehicle_id_ << "\",";
    frame << "\"timestamp\":" << state.timestamp_ms << ",";
    frame << "\"readings\":[";

    bool first = true;
    for (const auto& sensor : sensors_) {
        auto reading = sensor->read(state);
        if (!first) frame << ",";
        first = false;
        frame << buildPayload(reading);
    }

    frame << "]}";

    std::string topic = "sdv/" + vehicle_id_ + "/telemetry";
    mqtt_.publish(topic, frame.str(), 0);
}

std::string TelemetryPublisher::buildTopic(const std::string& sensor_type) const {
    return "sdv/" + vehicle_id_ + "/sensors/" + sensor_type;
}

std::string TelemetryPublisher::buildPayload(const SensorReading& reading) const {
    std::ostringstream oss;
    oss << "{";
    oss << "\"sensor_id\":\"" << reading.sensor_id << "\",";
    oss << "\"type\":\"" << reading.sensor_type << "\",";
    oss << "\"value\":";
    if (reading.sensor_type == "gps") {
        oss << "\"" << reading.unit << "\"";
    } else {
        oss << reading.value;
    }
    oss << ",";
    oss << "\"unit\":\"" << (reading.sensor_type == "gps" ? reading.unit : reading.unit) << "\",";
    oss << "\"timestamp\":" << reading.timestamp_ms << ",";
    oss << "\"quality\":" << std::fixed << std::setprecision(3) << reading.quality;
    oss << "}";
    return oss.str();
}

} // namespace sdv
