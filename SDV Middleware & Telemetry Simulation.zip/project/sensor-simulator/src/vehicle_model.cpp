#include "vehicle_model.hpp"
#include <chrono>

namespace sdv {

VehicleModel::VehicleModel()
    : rng_(std::random_device{}()),
      noise_dist_(0.0, 1.0),
      uniform_dist_(0.0, 1.0) {
    pickNewTargetSpeed();
    engine_temp_rise_rate_ = 0.5 + uniform_dist_(rng_) * 2.0;
}

void VehicleModel::update(double dt) {
    updateSpeed(dt);
    updateRPM();
    updateEngineTemp(dt);
    updateBattery(dt);
    updateFuel(dt);
    updateGPS(dt);
    updateAccelerometer();

    state_.timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

void VehicleModel::updateSpeed(double dt) {
    speed_change_timer_ -= dt;
    if (speed_change_timer_ <= 0.0) {
        pickNewTargetSpeed();
    }

    double diff = target_speed_ - state_.speed_kmh;
    double accel = 15.0; // km/h/s
    if (std::abs(diff) < 1.0) {
        state_.speed_kmh = target_speed_;
    } else {
        double change = (diff > 0 ? 1.0 : -1.0) * accel * dt;
        if (std::abs(change) > std::abs(diff)) {
            change = diff;
        }
        state_.speed_kmh += change;
    }

    if (state_.speed_kmh < 0.0) state_.speed_kmh = 0.0;
    if (state_.speed_kmh > 200.0) state_.speed_kmh = 200.0;

    state_.odometer_km += (state_.speed_kmh / 3600.0) * dt;
}

void VehicleModel::updateRPM() {
    if (state_.speed_kmh < 1.0) {
        state_.rpm = 800.0 + noise_dist_(rng_) * 20.0;
    } else {
        double gear_ratio = 1.0 + (6 - state_.gear) * 0.3;
        state_.rpm = 800.0 + (state_.speed_kmh * 35.0 * gear_ratio) + noise_dist_(rng_) * 30.0;
    }
    if (state_.rpm < 0.0) state_.rpm = 0.0;
    if (state_.rpm > 7000.0) state_.rpm = 7000.0;
}

void VehicleModel::updateEngineTemp(double dt) {
    double ambient = 25.0;
    double target = state_.speed_kmh > 5.0 ? 90.0 + state_.speed_kmh * 0.05 : 85.0;
    double diff = target - state_.engine_temp_c;
    state_.engine_temp_c += diff * 0.02 * dt + noise_dist_(rng_) * 0.1;
    if (state_.engine_temp_c < ambient) state_.engine_temp_c = ambient;
    if (state_.engine_temp_c > 120.0) state_.engine_temp_c = 120.0;
}

void VehicleModel::updateBattery(double dt) {
    double load = state_.rpm / 7000.0 + state_.speed_kmh / 200.0;
    double target = 13.8 - load * 0.5;
    double diff = target - state_.battery_voltage;
    state_.battery_voltage += diff * 0.1 * dt + noise_dist_(rng_) * 0.01;
    if (state_.battery_voltage < 10.0) state_.battery_voltage = 10.0;
    if (state_.battery_voltage > 15.0) state_.battery_voltage = 15.0;

    state_.battery_soc -= (load * 0.0001 * dt) + noise_dist_(rng_) * 0.0001;
    if (state_.battery_soc < 0.0) state_.battery_soc = 0.0;
    if (state_.battery_soc > 100.0) state_.battery_soc = 100.0;
}

void VehicleModel::updateFuel(double dt) {
    double consumption = (state_.rpm / 7000.0) * 0.001 * dt;
    state_.fuel_level -= consumption + noise_dist_(rng_) * 0.00001;
    if (state_.fuel_level < 0.0) state_.fuel_level = 0.0;
    if (state_.fuel_level > 100.0) state_.fuel_level = 100.0;
}

void VehicleModel::updateGPS(double dt) {
    if (state_.speed_kmh < 0.5) return;

    double speed_ms = state_.speed_kmh / 3.6;
    double dist = speed_ms * dt;

    state_.heading += noise_dist_(rng_) * 0.5;
    if (state_.heading < 0.0) state_.heading += 360.0;
    if (state_.heading >= 360.0) state_.heading -= 360.0;

    double rad = state_.heading * M_PI / 180.0;
    double lat_rad = state_.latitude * M_PI / 180.0;

    double dlat = dist * cos(rad) / 111320.0;
    double dlon = dist * sin(rad) / (111320.0 * cos(lat_rad));

    state_.latitude += dlat;
    state_.longitude += dlon;
}

void VehicleModel::updateAccelerometer() {
    state_.accel_x = noise_dist_(rng_) * 0.1;
    state_.accel_y = noise_dist_(rng_) * 0.1;
    state_.accel_z = 1.0 + noise_dist_(rng_) * 0.05;

    if (state_.brake_pressed) {
        state_.accel_x -= 2.0 + uniform_dist_(rng_) * 3.0;
    }

    if (state_.speed_kmh > 0.1) {
        state_.brake_pressed = uniform_dist_(rng_) < 0.02;
    } else {
        state_.brake_pressed = false;
    }

    if (state_.speed_kmh > 30.0) {
        state_.gear = 3 + static_cast<int>(state_.speed_kmh / 40.0);
        if (state_.gear > 6) state_.gear = 6;
    } else if (state_.speed_kmh > 10.0) {
        state_.gear = 2;
    } else {
        state_.gear = 1;
    }
}

void VehicleModel::pickNewTargetSpeed() {
    double phase = uniform_dist_(rng_);
    if (phase < 0.3) {
        target_speed_ = 0.0; // stopped
    } else if (phase < 0.5) {
        target_speed_ = 30.0 + uniform_dist_(rng_) * 20.0; // city
    } else if (phase < 0.8) {
        target_speed_ = 60.0 + uniform_dist_(rng_) * 40.0; // highway
    } else {
        target_speed_ = 100.0 + uniform_dist_(rng_) * 50.0; // fast highway
    }
    speed_change_timer_ = 5.0 + uniform_dist_(rng_) * 20.0;
}

} // namespace sdv
