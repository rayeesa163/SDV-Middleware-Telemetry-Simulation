#include "vehicle_model.hpp"
#include "sensor.hpp"
#include "mqtt_publisher.hpp"
#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
#include <memory>
#include <cstdlib>
#include <cstring>

using namespace sdv;

std::string getEnv(const char* name, const std::string& default_val) {
    const char* val = std::getenv(name);
    return val ? std::string(val) : default_val;
}

int getEnvInt(const char* name, int default_val) {
    const char* val = std::getenv(name);
    return val ? std::atoi(val) : default_val;
}

int main() {
    std::string broker = getEnv("MQTT_BROKER", "localhost");
    int port = getEnvInt("MQTT_PORT", 1883);
    std::string vehicle_id = getEnv("VEHICLE_ID", "VEH-001");
    int rate_hz = getEnvInt("SIMULATION_RATE_HZ", 10);

    std::cout << "SDV Sensor Simulator" << std::endl;
    std::cout << "  Vehicle: " << vehicle_id << std::endl;
    std::cout << "  MQTT Broker: " << broker << ":" << port << std::endl;
    std::cout << "  Rate: " << rate_hz << " Hz" << std::endl;

    VehicleModel vehicle;

    std::vector<std::unique_ptr<Sensor>> sensors;
    sensors.push_back(std::make_unique<SpeedSensor>("SPD-01"));
    sensors.push_back(std::make_unique<RPMSensor>("RPM-01"));
    sensors.push_back(std::make_unique<TemperatureSensor>("TMP-01"));
    sensors.push_back(std::make_unique<BatteryVoltageSensor>("BAT-V-01"));
    sensors.push_back(std::make_unique<BatterySOCSensor>("BAT-SOC-01"));
    sensors.push_back(std::make_unique<FuelLevelSensor>("FUE-01"));
    sensors.push_back(std::make_unique<GPSSensor>("GPS-01"));
    sensors.push_back(std::make_unique<AccelerometerSensor>("ACC-01"));
    sensors.push_back(std::make_unique<BrakeSensor>("BRK-01"));
    sensors.push_back(std::make_unique<GearSensor>("GR-01"));

    TelemetryPublisher publisher(broker, port, vehicle_id, sensors);
    if (!publisher.start()) {
        std::cerr << "Failed to start MQTT publisher" << std::endl;
        return 1;
    }

    const auto interval = std::chrono::microseconds(1000000 / rate_hz);
    auto next_time = std::chrono::steady_clock::now();

    std::cout << "Simulation running..." << std::endl;

    while (true) {
        vehicle.update(1.0 / rate_hz);
        publisher.publishFrame(vehicle.state());

        next_time += interval;
        std::this_thread::sleep_until(next_time);
    }

    return 0;
}
